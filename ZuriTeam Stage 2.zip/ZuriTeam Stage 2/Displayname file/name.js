


 function myFunction() {
    myFunction.displayName = "Hassan Yusuff";
    console.log(myFunction.displayName);
 }