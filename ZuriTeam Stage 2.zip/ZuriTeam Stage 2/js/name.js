


 function myFunction() {
    myFunction.displayName = "Hassan Yusuff";
    document.getElementById('name').innerHTML = myFunction.displayName;
 }